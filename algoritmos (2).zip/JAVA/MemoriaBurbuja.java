/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class MemoriaBurbuja {
    public static List<Date> bubbleSort(List<Date> arr) {
        int n = arr.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr.get(j).after(arr.get(j + 1))) {
                    Date temp = arr.get(j);
                    arr.set(j, arr.get(j + 1));
                    arr.set(j + 1, temp);
                }
            }
        }
        return arr;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Date> dates = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        System.out.println("Ingrese las fechas (YYYY-MM-DD) una por línea (ingrese 'fin' para finalizar):");
        String input = scanner.nextLine();
        while (!input.equals("fin")) {
            try {
                Date date = dateFormat.parse(input);
                dates.add(date);
            } catch (ParseException e) {
                System.out.println("Formato de fecha incorrecto. Ingrese nuevamente:");
            }
            input = scanner.nextLine();
        }

        long startTime = System.nanoTime();
        List<Date> sortedDates = bubbleSort(new ArrayList<>(dates));
        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;

        System.out.println("Fechas Ordenadas:");
        for (Date date : sortedDates) {
            System.out.println(dateFormat.format(date));
        }

        System.out.println("Tiempo de Ejecución: " + elapsedTime + " nanosegundos");
        System.out.println("Uso de Memoria: " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024) + " MB");
    }
}
