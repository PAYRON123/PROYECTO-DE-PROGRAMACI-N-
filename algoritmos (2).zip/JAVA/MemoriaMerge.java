/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class MemoriaMerge {
    public static List<Date> mergeSort(List<Date> arr) {
        if (arr.size() <= 1) {
            return arr;
        }

        int mid = arr.size() / 2;
        List<Date> left = new ArrayList<>(arr.subList(0, mid));
        List<Date> right = new ArrayList<>(arr.subList(mid, arr.size()));

        left = mergeSort(left);
        right = mergeSort(right);

        return merge(left, right);
    }

    public static List<Date> merge(List<Date> left, List<Date> right) {
        List<Date> merged = new ArrayList<>();
        int leftIndex = 0;
        int rightIndex = 0;

        while (leftIndex < left.size() && rightIndex < right.size()) {
            if (left.get(leftIndex).before(right.get(rightIndex))) {
                merged.add(left.get(leftIndex));
                leftIndex++;
            } else {
                merged.add(right.get(rightIndex));
                rightIndex++;
            }
        }

        merged.addAll(left.subList(leftIndex, left.size()));
        merged.addAll(right.subList(rightIndex, right.size()));

        return merged;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Date> dates = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        System.out.println("Ingrese las fechas (YYYY-MM-DD) una por línea (ingrese 'fin' para finalizar):");
        String input = scanner.nextLine();
        while (!input.equals("fin")) {
            try {
                Date date = dateFormat.parse(input);
                dates.add(date);
            } catch (ParseException e) {
                System.out.println("Formato de fecha incorrecto. Ingrese nuevamente:");
            }
            input = scanner.nextLine();
        }

        long startTime = System.nanoTime();
        List<Date> sortedDates = mergeSort(new ArrayList<>(dates));
        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;

        System.out.println("Fechas Ordenadas:");
        for (Date date : sortedDates) {
            System.out.println(dateFormat.format(date));
        }

        System.out.println("Tiempo de Ejecución: " + elapsedTime + " nanosegundos");
        System.out.println("Uso de Memoria: " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024) + " MB");
    }
}
