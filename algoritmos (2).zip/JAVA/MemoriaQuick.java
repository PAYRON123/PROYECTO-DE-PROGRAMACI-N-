/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class MemoriaQuick {
    public static List<Date> quickSort(List<Date> arr) {
        if (arr.size() <= 1) {
            return arr;
        }

        Date pivot = arr.get(arr.size() / 2);
        List<Date> left = new ArrayList<>();
        List<Date> middle = new ArrayList<>();
        List<Date> right = new ArrayList<>();

        for (Date date : arr) {
            if (date.before(pivot)) {
                left.add(date);
            } else if (date.equals(pivot)) {
                middle.add(date);
            } else {
                right.add(date);
            }
        }

        List<Date> sortedLeft = quickSort(left);
        List<Date> sortedRight = quickSort(right);

        List<Date> sortedArr = new ArrayList<>(sortedLeft);
        sortedArr.addAll(middle);
        sortedArr.addAll(sortedRight);

        return sortedArr;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Date> dates = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        System.out.println("Ingrese las fechas (YYYY-MM-DD) una por línea (ingrese 'fin' para finalizar):");
        String input = scanner.nextLine();
        while (!input.equals("fin")) {
            try {
                Date date = dateFormat.parse(input);
                dates.add(date);
            } catch (ParseException e) {
                System.out.println("Formato de fecha incorrecto. Ingrese nuevamente:");
            }
            input = scanner.nextLine();
        }

        long startTime = System.nanoTime();
        List<Date> sortedDates = quickSort(new ArrayList<>(dates));
        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;

        System.out.println("Fechas Ordenadas:");
        for (Date date : sortedDates) {
            System.out.println(dateFormat.format(date));
        }

        System.out.println("Tiempo de Ejecución: " + elapsedTime + " nanosegundos");
        System.out.println("Uso de Memoria: " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024) + " MB");
    }
}
