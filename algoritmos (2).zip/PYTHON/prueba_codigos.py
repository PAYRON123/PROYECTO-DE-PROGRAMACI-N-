import tkinter as tk
from tkinter import messagebox
import timeit


def quick_sort(arr):
    if len(arr) <= 1:
        return arr

    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]

    return quick_sort(left) + middle + quick_sort(right)


def merge_sort(arr):
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    left = arr[:mid]
    right = arr[mid:]

    left = merge_sort(left)
    right = merge_sort(right)

    return merge(left, right)


def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
    return result


class CodeSortingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Ordenador de Códigos de Alumnos con Quick Sort y Merge Sort")

        self.codes = []

        self.input_frame = tk.Frame(self.root)
        self.input_frame.pack(padx=20, pady=20)

        self.code_entry = tk.Entry(self.input_frame, width=15)
        self.code_entry.pack(side=tk.LEFT)

        self.add_button = tk.Button(self.input_frame, text="Agregar Código", command=self.add_code)
        self.add_button.pack(side=tk.LEFT, padx=10)

        self.quick_sort_button = tk.Button(self.root, text="Ordenar Códigos (Quick Sort)",
                                           command=self.sort_codes_quick)
        self.quick_sort_button.pack(pady=10)

        self.merge_sort_button = tk.Button(self.root, text="Ordenar Códigos (Merge Sort)",
                                           command=self.sort_codes_merge)
        self.merge_sort_button.pack(pady=10)

        self.result_frame = tk.Frame(self.root)
        self.result_frame.pack(padx=20, pady=20)

        self.sorted_codes_label = tk.Label(self.result_frame, text="Códigos Ordenados:", font=("Helvetica", 16, "bold"))
        self.sorted_codes_label.pack()

        self.sorted_codes_text = tk.Text(self.result_frame, height=10, width=40)
        self.sorted_codes_text.pack()

        self.time_label = tk.Label(self.result_frame, text="Tiempo de Ejecución:", font=("Helvetica", 12, "bold"))
        self.time_label.pack(pady=10)

    def add_code(self):
        code_str = self.code_entry.get()
        if len(code_str) == 8 and code_str.isdigit():
            self.codes.append(int(code_str))
            self.code_entry.delete(0, tk.END)
            self.update_codes_text()
            messagebox.showinfo("Éxito", "Código de alumno agregado correctamente.")
        else:
            messagebox.showerror("Error", "Formato de código incorrecto. El código debe tener 8 dígitos numéricos.")

    def sort_codes_quick(self):
        if len(self.codes) > 0:
            setup_code = f"from __main__ import quick_sort; codes = {self.codes}"
            stmt = "sorted_codes = quick_sort(codes.copy())"
            time = timeit.timeit(stmt, setup=setup_code, number=100, globals=globals())

            sorted_codes = quick_sort(self.codes.copy())
            if sorted_codes is not None:
                self.sorted_codes_text.delete(1.0, tk.END)
                self.sorted_codes_text.insert(tk.END, '\n'.join(map(str, sorted_codes)))

                self.time_label.config(text=f"Tiempo de Ejecución (Quick Sort): {time:.4f} segundos")
        else:
            messagebox.showwarning("Advertencia", "No se han ingresado códigos de alumnos para ordenar.")

    def sort_codes_merge(self):
        if len(self.codes) > 0:
            setup_code = f"from __main__ import merge_sort; codes = {self.codes}"
            stmt = "sorted_codes = merge_sort(codes.copy())"
            time = timeit.timeit(stmt, setup=setup_code, number=100, globals=globals())

            sorted_codes = merge_sort(self.codes.copy())
            if sorted_codes is not None:
                self.sorted_codes_text.delete(1.0, tk.END)
                self.sorted_codes_text.insert(tk.END, '\n'.join(map(str, sorted_codes)))

                self.time_label.config(text=f"Tiempo de Ejecución (Merge Sort): {time:.4f} segundos")
        else:
            messagebox.showwarning("Advertencia", "No se han ingresado códigos de alumnos para ordenar.")

    def update_codes_text(self):
        self.sorted_codes_text.delete(1.0, tk.END)
        self.sorted_codes_text.insert(tk.END, '\n'.join(map(str, self.codes)))


if __name__ == "__main__":
    root = tk.Tk()
    app = CodeSortingApp(root)
    root.mainloop()
