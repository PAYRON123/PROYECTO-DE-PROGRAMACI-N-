# sorting_algorithms.py

def merge_sort(arr):
    # Implementación de Merge Sort
    # ...
    pass

def quick_sort(arr):
    # Implementación de Quick Sort
    # ...
    pass
